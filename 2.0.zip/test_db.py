"""
数据库连接测试脚本
用于测试与MySQL数据库的连接和基本操作
"""

import pymysql
import sys
import socket

def test_connection():
    """
    测试数据库连接函数
    包含三个主要步骤：
    1. DNS解析
    2. 数据库连接
    3. 数据库创建
    """
    # 第一步：DNS解析
    print("1. 开始DNS解析...")
    try:
        # 解析域名获取IP地址
        ip = socket.gethostbyname('dbconn.sealoshzh.site')
        print(f"DNS解析成功，IP地址: {ip}")
    except socket.gaierror as e:
        # DNS解析失败处理
        print(f"DNS解析失败: {e}")
        return

    # 第二步：连接数据库
    print("\n2. 开始尝试连接数据库...")
    try:
        # 打印连接参数
        print("连接参数:")
        print(f"- 主机: dbconn.sealoshzh.site")
        print(f"- 端口: 44475")
        print(f"- 用户: root")
        
        # 建立数据库连接
        connection = pymysql.connect(
            host='dbconn.sealoshzh.site',
            user='root',
            password='fgx28474',
            port=44475,  # 连接超时时间：10秒
            ssl=False,           # 不使用SSL连接
            autocommit=True,     # 自动提交事务
        )
        print("数据库连接成功！")
        
        # 第三步：创建数据库
        print("\n3. 尝试创建数据库...")
        with connection.cursor() as cursor:
            # 创建数据库（如果不存在）
            # 使用utf8mb4字符集和unicode_ci排序规则
            cursor.execute("""
                CREATE DATABASE IF NOT EXISTS campus_life 
                CHARACTER SET utf8mb4 
                COLLATE utf8mb4_unicode_ci
            """)
        print("数据库创建成功！")
        
        # 关闭数据库连接
        connection.close()
        print("连接已关闭")
        return True
        
    except pymysql.Error as e:
        # 处理数据库特定错误
        print(f"\n数据库错误：")
        print(f"错误代码：{e.args[0]}")
        print(f"错误信息：{e.args[1]}")
    except Exception as e:
        # 处理其他所有错误
        print(f"\n其他错误：")
        print(f"错误类型：{type(e)}")
        print(f"错误信息：{str(e)}")
        print(f"详细错误：{sys.exc_info()}")
    return False

def recreate_database():
    """重新创建数据库"""
    connection = pymysql.connect(
        host='dbconn.sealoshzh.site',
        user='root',
        password='fgx28474',
        port=33973,
        charset='utf8mb4',
        connect_timeout=60,
    )
    
    try:
        with connection.cursor() as cursor:
            # 删除现有数据库
            cursor.execute("DROP DATABASE IF EXISTS campus_life")
            print("旧数据库已删除")
            
            # 创建新数据库
            cursor.execute("""
                CREATE DATABASE campus_life 
                CHARACTER SET utf8mb4 
                COLLATE utf8mb4_unicode_ci
            """)
            print("新数据库创建成功")
            
            # 使用新数据库
            cursor.execute("USE campus_life")
            
            # 删除可能存在的表
            tables_to_drop = [
                'posts_userprofile_friends',
                'posts_userprofile_following',
                'posts_userprofile_bookmarks',
                'posts_comment_likes',
                'posts_post_likes',
                'posts_message',
                'posts_friendrequest',
                'posts_friendship',
                'posts_feedback',
                'posts_comment',
                'posts_post',
                'posts_userprofile',
                'django_migrations',
                'django_content_type',
                'django_admin_log',
                'django_session',
                'auth_user_groups',
                'auth_user_user_permissions',
                'auth_group_permissions',
                'auth_permission',
                'auth_group',
                'auth_user'
            ]
            
            for table in tables_to_drop:
                try:
                    cursor.execute(f"DROP TABLE IF EXISTS {table}")
                    print(f"表 {table} 已删除")
                except Exception as e:
                    print(f"删除表 {table} 时出错: {e}")
            
            print("所有表已清理完毕")
            
    except Exception as e:
        print(f"错误：{e}")
    finally:
        connection.close()
        print("数据库连接已关闭")

# 当直接运行此脚本时执行测试
if __name__ == "__main__":
    recreate_database() 