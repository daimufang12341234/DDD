"""
项目初始化文件
用于配置 MySQL 数据库连接
"""

import pymysql

# 将 pymysql 注册为 MySQLdb
# 这样 Django 可以使用 pymysql 来连接 MySQL 数据库
pymysql.install_as_MySQLdb()
